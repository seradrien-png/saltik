# Intégration de « Velours mécanique » — monde Velours (Saltik)

La piste audio jointe est la maquette originale validée, sans modification.

## Consignes pour Codex
1. Examine d'abord l'architecture actuelle du projet Saltik et son système audio.
2. Ajoute `assets/audio/music/saltik_velours_01_mecanique.mp3` dans le projet (ou adapte le chemin à la convention déjà utilisée).
3. Utilise ce fichier comme musique de fond du **monde Velours uniquement**.
4. Démarre la musique quand le niveau devient actif, en respectant les restrictions audio des navigateurs mobiles (lancement après une interaction utilisateur si nécessaire).
5. Répète le morceau en boucle pendant le niveau. Vérifie la transition de boucle à l'écoute ; si elle est audible, applique un court fondu enchaîné sans modifier le morceau original.
6. Arrête ou fais disparaître progressivement la musique à la sortie du niveau, au changement de monde ou au retour au menu. Évite les instances audio superposées.
7. Volume initial conseillé : 25 % du volume maximal, ajustable via le réglage musique du jeu ; respecte les commandes pause, muet et volume existantes.
8. Ne modifie ni les bruitages des Saltiks ni les autres musiques du jeu.
9. Vérifie le fonctionnement sur navigateur mobile et ordinateur. Indique dans ta réponse quels fichiers du projet ont changé.

## Fichier fourni
- `assets/audio/music/saltik_velours_01_mecanique.mp3`
- MP3 stéréo ; durée environ 26,7 secondes ; 108 BPM annoncé lors de la création
- Ce pack contient la version originale, sans recomposition ni transcodage.
