# SALTIK / STRIKER - MIRV SFX KIT

Création originale, style lourd / mécanique / militaire stylisé.

## Fichiers audio modulaires (OGG pour le jeu / WAV pour master)
- 01_mortier_depart : impulsion du mortier, une fois au tir.
- 02_mirv_vol_boucle : boucle pendant le vol du projectile principal.
- 03_mirv_separation : séparation du MIRV en sous-projectiles, une fois.
- 04_mirv_chute_boucle : boucle de chute (un ou plusieurs sous-projectiles).
- 05_mirv_impact_1 / _2 / _3 : trois impacts proches mais non identiques.
- DEMO_tir_court.mp3 et DEMO_tir_long.mp3 : exemples, à écouter seulement (NE PAS les employer comme effet intégré).

## INTEGRATION: synchronisation sur la physique, pas sur des secondes fixes
1. Quand le joueur tire: jouer le fichier 01.
2. Tant que le projectile MIRV principal existe, jouer en boucle le fichier 02 (à niveau faible).
3. Quand le moteur du jeu signale la séparation réelle (apogée / altitude choisie / événement gameplay), arrêter 02 et jouer 03.
4. Pendant la chute de chaque sous-projectile, jouer 04 en boucle. Pour éviter une bouillie sonore, mixer 1-3 pistes max ou 1 boucle commune.
5. Lorsque CHAQUE projectile frappe réellement, arrêter sa boucle 04 et jouer l'un des trois impacts, en variant subtilement pitch (0.94-1.06) et panorama. Ne pas jouer d'impact en l'absence de collision.
6. Les longues distances rallongent naturellement l'étape 2 et/ou 4 : ne jamais étirer les samples fixes 01 / 03 / 05.
7. Moduler légèrement le volume et la vitesse de lecture de 04 selon la vitesse de chute / distance perçue (par exemple 0.85 au début -> 1.35 près du sol).

IMPORTANT : les boucles fournies sont des textures audio prêtes à adapter et crossfader. Pour les versions HTML5 mobiles, faire un fondu de 60-120 ms à l'entrée/sortie; si une jointure de boucle est audible dans le moteur, prévoir un crossfade entre deux lecteurs.

## Exemple de pseudo-code

onMirvFire(projectile) {
  sfx.play('01_mortier_depart');
  projectile.flightSound = sfx.loop('02_mirv_vol_boucle', {volume:0.23});
}
onMirvSplit(projectile, children) {
  projectile.flightSound?.fadeOut(0.10);
  sfx.play('03_mirv_separation');
  children.forEach((child) => {
    child.fallSound = sfx.loop('04_mirv_chute_boucle', {volume:0.16});
  });
}
onChildUpdate(child) {
  // Ajuster en continu, suivant la vitesse verticale réelle et la distance caméra.
  child.fallSound?.setRate(clamp(0.85 + child.fallProgress * 0.5, 0.85, 1.35));
}
onChildImpact(child) {
  child.fallSound?.fadeOut(0.06);
  sfx.play(randomChoice(['05_mirv_impact_1', '05_mirv_impact_2','05_mirv_impact_3']), {volume:0.65});
}
onChildRemovedWithoutImpact(child) {
  child.fallSound?.fadeOut(0.06);
}

Le code ci-dessus est une logique d'événements à adapter au moteur de SALTIK : ses noms de fonctions sont illustratifs, pas une API existante.
