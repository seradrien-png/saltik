import json,subprocess,hashlib,zipfile
from pathlib import Path
root=Path('/workspace/sites/saltik-v2-matin-dore'); work=Path('/tmp/saltik-v51-audio')
manifest=json.loads((root/'docs/real-weapon-audio-provenance.json').read_text());manifest['version']=2
entries=[(386777,5768130,'ken788','Machine_Gun_Reload.wav','striker-reload-start','atrim=start=0:end=1.10,asetpts=PTS-STARTPTS,highpass=f=90,volume=0.8,afade=t=in:d=0.003,afade=t=out:st=1.07:d=0.03','Actual machine-gun reload recording, first latch and magazine/feed movement; silence between movements retained.'),(386777,5768130,'ken788','Machine_Gun_Reload.wav','striker-reload-end','atrim=start=1.50:end=1.83,asetpts=PTS-STARTPTS,highpass=f=90,volume=0.8,afade=t=in:d=0.003,afade=t=out:st=0.30:d=0.03','Final rack/return movement excerpted from the same recorded machine-gun reload; triggered only at reload-end.'),(855898,71257,'qubodup','Fire Explosion','guided-impact','atrim=start=0:end=1.23,asetpts=PTS-STARTPTS,highpass=f=45,volume=0.8,afade=t=in:d=0.002,afade=t=out:st=1.11:d=0.12','Actual EOD explosive detonation from EOD Broll package (Nov 18, 2020), Seaman Kelly Meyer, AFN Okinawa. Source editor applied RX Spectral De-noise.'),(855896,71257,'qubodup','Blow Up Sound','guided-destruction','atrim=start=0:end=1.60,asetpts=PTS-STARTPTS,highpass=f=40,volume=0.7,afade=t=in:d=0.002,afade=t=out:st=1.40:d=0.20','Actual EOD blast/shock wave from EOD Broll package (Nov 18, 2020), Seaman Kelly Meyer, AFN Okinawa. Source editor applied Audacity Limiter.')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for id,uid,author,title,name,filters,description in entries:
 src=work/f'{id}-hq.mp3';out=root/f'dist/audio/real-weapons/{name}.ogg'
 subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(src),'-af',filters,'-ac','1','-ar','44100','-c:a','libvorbis','-q:a','5',str(out)],check=True)
 item=dict(id=id,author=author,title=title,sourcePage=f'https://freesound.org/people/{author}/sounds/{id}/',downloadURL=f'https://cdn.freesound.org/previews/{str(id)[:3]}/{id}_{uid}-hq.mp3',downloadKind='Freesound publicly served HQ MP3 preview; not the lossless original',license='CC0-1.0',licenseURL='https://creativecommons.org/publicdomain/zero/1.0/',provenance=description,downloadSHA256=sha(src),asset=str(out.relative_to(root)),assetSHA256=sha(out),ffmpegFilter=filters,encoding='mono 44.1kHz Ogg Vorbis quality 5',retrieved='2026-11-14',sourceArchive='audio-sources/striker-v51-source-kit.zip')
 if author=='qubodup':item['originalVideoURL']='https://www.dvidshub.net/video/774073/eod-broll-package'
 manifest['sources'].append(item)
(root/'docs/real-weapon-audio-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
(work/'manifest.json').write_text(json.dumps({'sources':manifest['sources'][4:]},indent=2)+'\n')
with zipfile.ZipFile(root/'audio-sources/striker-v51-source-kit.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(work.glob('*.mp3'))+sorted(work.glob('*.html'))+[work/'manifest.json',work/'prepare.py']:archive.write(path,path.name)
credits=root/'dist/audio/real-weapons/CREDITS.txt'
with credits.open('a') as f:
 f.write('\nV51 recorded Striker reload and guided enemy impacts (2026-11-14):\n')
 for item in manifest['sources'][4:]:f.write(f"{Path(item['asset']).name}: {item['title']} by {item['author']} — {item['sourcePage']} — CC0 1.0 https://creativecommons.org/publicdomain/zero/1.0/\n")
 f.write('EOD source footage: EOD Broll package, Seaman Kelly Meyer / AFN Okinawa, 2020-11-18, https://www.dvidshub.net/video/774073/eod-broll-package (public domain). Source HQ previews, page snapshots and exact processing manifest archived outside the published runtime.\n')
